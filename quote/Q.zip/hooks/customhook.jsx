import { useState, useEffect } from 'react';

const useCustomQuote = () => {
  const [data, setData] = useState({});

  useEffect(() => {
    fetch('https://type.fit/api/quotes')
      .then((response) => {
        if (!response.ok) {
          throw new Error("Some error fetching info");
        }
        
        return response.json();
      })
      .then((data) => {
        const randomIndex = Math.floor(Math.random() * data.length);
        setData(data[randomIndex]);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);
  return data;
};

export default useCustomQuote;
